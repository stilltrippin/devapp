import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';




@Injectable()
export class AuthService {
  private BASE_URL = 'http://localhost:4200/api';

  constructor(private http: HttpClient) {}
/*
  getToken(): string {
    return localStorage.getItem('token');
  }
*/
  logIn({email, password}) {
    const url = `${this.BASE_URL}/login`;
    console.log(email, password);
    return this.http.post<any>(url, {email, password});
  }

}
