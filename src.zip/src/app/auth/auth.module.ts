import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {LoginFormComponent} from './components/loginform/loginform.component';
import { AuthService } from './services/authService';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import {FormsModule} from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [{
  path: '', component: LoginFormComponent
}];

@NgModule({
  declarations: [LoginFormComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule.forChild(routes)

  ],
  exports:[
    LoginFormComponent,
  ],
  providers: [AuthService]
})
export class AuthModule { }
