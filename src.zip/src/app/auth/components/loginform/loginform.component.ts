import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

import { AuthService } from "../../services/authService";

@Component({
  selector: 'app-loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginFormComponent implements OnInit {

  formy: FormGroup;

  constructor(public authService: AuthService){}
  ngOnInit(): void {
    this.formy=new FormGroup({
      email: new FormControl('',Validators.required),
      password: new FormControl('',Validators.required)
    });
  }

  onSubmit() {
    console.log("hello");
    this.authService.logIn(this.formy.value).subscribe();

  }
}
