import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-assess-form',
  templateUrl: './assess-form.component.html',
  styleUrls: ['./assess-form.component.css']
})
export class AssessFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
