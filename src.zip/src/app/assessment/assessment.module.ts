import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LoginFormComponent } from '../auth/components/loginform/loginform.component';
import { AssessFormComponent } from './components/assess-form/assess-form.component';
import { ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [{
  path: '', component: AssessFormComponent
}];

@NgModule({
  declarations: [AssessFormComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    ReactiveFormsModule
  ]
})
export class AssessmentModule { }
