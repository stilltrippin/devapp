import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginFormComponent } from './auth/components/loginform/loginform.component';
import { AssessFormComponent } from './assessment/components/assess-form/assess-form.component'; // CLI imports router


export const routes: Routes = [
  {
    path: 'login',
    loadChildren: () => import('./auth/auth.module')
      .then(a => a.AuthModule)
  },
  {
    path:'userassessments',
    loadChildren: () => import('./assessment/assessment.module')
      .then(a => a.AssessmentModule)
  }
]; // sets up routes constant where you define your routes

// configures NgModule imports and exports
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
